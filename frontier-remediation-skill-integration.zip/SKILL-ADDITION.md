# Addition to your existing SKILL.md

Append the section below to skills/frontier-remediation-status/SKILL.md, or merge it into an equivalent existing section. This file is a patch snippet, not a replacement skill entrypoint. Do not install it as a separate skill.

## Source review and verification

This existing skill remains the single coordinator for vulnerability assessment, planning, requested fixes, verification, and handoff. The following files are supporting references, not independently discoverable skills:

- For Java/Spring source review, read [backend-review.md](references/backend-review.md).
- For React/TypeScript/Node source review, read [frontend-review.md](references/frontend-review.md).
- For verification and reporting, read [verification.md](references/verification.md).

Load only references relevant to the requested scope. Existing frs scripts and remediation-kb.json remain authoritative for dependency classification, version evaluation, planning, and supported dependency edits. Do not implement duplicate dependency-remediation logic or install a second full-stack orchestrator for this workflow.

Use reference review criteria without replacing existing finding IDs, report schemas, or status vocabulary. The sample output contract in verification.md is conceptual guidance; map its evidence to existing fields and report unsupported details in the narrative. Do not imply that reference instructions add capabilities to the scripts. Report verification, deployment, and external rescan limitations explicitly.

Project instructions/steward remain authoritative for operating policy. local-review, if retained, uses the same review criteria. pr-ship remains responsible for optional authorized delivery activities.

Review-only requests do not authorize application edits. When fixes are requested, use the existing supported dependency-editing workflow; make other authorized source corrections with the coding agent, add appropriate regression tests, and run configured checks. Preserve the existing scope and approval requirements. Report unresolved items and external handoffs.
