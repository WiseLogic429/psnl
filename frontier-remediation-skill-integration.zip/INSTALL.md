# Integrate into the existing skill

This package enhances the existing frontier-remediation-status skill. It does not contain a new SKILL.md entrypoint and must not be installed as another skill.

1. Copy the three files in references/ into skills/frontier-remediation-status/references/. Preserve existing knowledge-base and playbook files. If a filename already exists, compare and merge rather than overwrite it blindly.
2. Merge the "Source review and verification" section from SKILL-ADDITION.md into the existing skills/frontier-remediation-status/SKILL.md. Do not replace that file. Add the section only once and reconcile equivalent existing routing instructions.
3. Keep SKILL-ADDITION.md and this installation document outside the installed skill, or discard the package copies after integration. They are integration aids, not runtime dependencies.
4. Invoke your existing skill normally. Ask for source review when needed; request fixes explicitly when you want edits.

Resulting additions:

```text
skills/frontier-remediation-status/
  SKILL.md                       existing entrypoint, updated
  references/
    backend-review.md            added reference
    frontend-review.md           added reference
    verification.md              added reference
```

Existing scripts, knowledge-base decisions, finding identifiers, and machine-readable reports remain authoritative. The reference files describe review and verification behavior; they do not automatically implement saved-plan execution, stale-plan detection, new status fields, or other Python changes. Those require inspecting and revising the actual source separately.

The original screenshots were used to design this integration. The existing Python implementation was not provided or tested. Validate integration first with a review-only request and confirm that the agent uses the existing entrypoint, reads the applicable references, preserves current report formats, and does not create another skill.
