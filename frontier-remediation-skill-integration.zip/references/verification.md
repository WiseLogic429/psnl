# Verification and reporting

## Establish a baseline

Record repository scope and revision where available, current worktree changes, version declarations, and actual installed tool versions. For local review include staged, unstaged, and relevant untracked source/configuration. Avoid inspecting binary/generated/vendor output unless needed to confirm a finding. Do not ignore manifests, lockfiles, CI, or deployment configuration.

Derive commands from repository scripts, wrappers, CI jobs, and documented profiles. Record working directory, command, exit status, and a concise result. Commands below are examples, not an instruction to execute every tool. Inspect scripts and environment requirements before execution; builds and package installation can run code. Use an isolated checkout when verification would disrupt the user's working environment.

## Select appropriate checks

| Area | What to establish | Examples when configured |
| --- | --- | --- |
| Backend build | Actual compiler/toolchain compatibility | Maven/Gradle wrapper compile/build task |
| Backend tests | Relevant logic, request security, database behavior | Wrapper test/verify tasks and declared integration-test profiles |
| Java analysis | Code and security defects | Existing Checkstyle, PMD, SpotBugs/FindSecBugs, or Sonar tasks |
| Frontend types | Type correctness | Existing typecheck script; project-reference build if used |
| Frontend quality | Lint, behavior, production compilation | Declared lint/test/build npm scripts, in correct workspace |
| End-to-end | Affected user/API integration | Existing Playwright or equivalent project configuration |
| Supply chain | Resolved vulnerable versions and available fixes | Configured SCA, Dependency-Check, npm audit, dependency graph |
| Code security | Source findings with context | Configured CodeQL or Semgrep analysis |

On Windows use the appropriate `.cmd` or `.bat` wrapper when present. Do not assume Maven `test` runs integration tests, Gradle `test` executes every source set, or a frontend build performs type checking. Inspect their definitions. Use `npm ci` only when installing dependencies is necessary and the environment is suitable; it replaces `node_modules` and may execute lifecycle scripts. Read-only review can use existing dependencies and diagnostics. Report an unavailable environment rather than silently installing unrelated tooling.

Check Java/Node declarations against CI and containers. The target is compatibility with the user's supported Java 21+ and Node 22 environment, not automatically upgrading to the newest major. Verify npm independently of Node; do not assume a fixed bundled npm version.

## Dependency evidence

For each advisory record the package/artifact, resolved version, dependency path, authoritative advisory, affected range, fixed release, and applicability. Check current authoritative advisory/version information when available. Separate vulnerable-version presence from reachable exploitation. A development dependency is not automatically harmless, and a scanner's severity is not automatically the application's severity. An npm audit nonzero exit can represent findings rather than execution failure; inspect the result. Stale databases, offline failures, omitted workspaces, or unavailable credentials must be disclosed. Do not upload private source to a new service without authorization.

## Apply and verify fixes

1. Confirm the request authorizes edits and identify the finding being addressed.
2. Choose the smallest correction consistent with supported versions and intended behavior. Preserve unrelated changes and dependency-management constraints.
3. Add a regression test that captures the failure when practical. Establish the failing behavior without reverting user changes; an isolated fixture or checkout can be used.
4. Implement the fix, run focused checks, and then run relevant broader configured checks.
5. Inspect the final diff for accidental behavior changes, sensitive data, unrelated edits, and weakened tests or controls.
6. Mark each finding resolved, mitigated, deferred, or unverified with supporting evidence. Do not label a fix verified when its required tests could not run.

Review and plan modes do not add tests or edit configuration. When a new tool would improve confidence, report it as an optional next step unless setup is already within scope. Continue independent authorized fixes if another finding needs a product decision.

## Output contract

Start with the most consequential findings. Use this compact structure per finding:

```text
ID: FS-001
Title: <specific failure>
Severity: critical | high | medium | low
Evidence: confirmed | suspected | unverified
Location: <current file:line and relevant supporting locations>
Scope: introduced/affected by reviewed change | pre-existing
Trigger and impact: <concrete preconditions and consequence>
Evidence details: <source path, reproduction, or validated tool result>
Correction: <smallest compatible change>
Regression check: <behavior to assert>
Disposition: open | resolved | mitigated | deferred | unverified
```

Set severity using actual impact and preconditions: critical for immediate severe compromise with realistic exposure, high for substantial compromise/data loss, medium for constrained security impact or material correctness failures, low for minor concrete impact. Keep style suggestions separate. Add CWE/advisory links only when verified.

Summarize executed checks with statuses **passed**, **failed**, **blocked**, **not run**, or **not configured**. Separate baseline failures from failures introduced by fixes. Include tested scope, loaded/missing specialist skills, files changed, unresolved risks, and environment limitations. If nothing actionable was found, say so with the scope and checks; avoid a blanket declaration of security.
