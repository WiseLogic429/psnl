# Frontend, TypeScript, Node, and npm review

Identify React and TypeScript versions, bundler, routing/rendering model, npm workspaces, and whether Node runs a server or only tooling. Read existing lint, formatting, compiler, and test configuration. Apply server-rendering and server-action checks only where those features exist.

## Browser and API security

Review unsafe HTML sinks, URL protocols, embedded content, DOM manipulation, and third-party script boundaries. Trace input origin and any sanitization to the final rendering context. React text escaping does not protect all sinks. Check whether sensitive environment values are bundled into public assets.

Trace credential handling, API base URLs, cookie options, redirects, and cross-origin requests with backend policy. A hidden button or route guard cannot enforce server authorization. Inspect logging, browser storage, caches, and analytics for sensitive data leakage. Evaluate the actual session design before recommending token-storage changes.

Check response parsing and runtime validation at external boundaries: TypeScript types and assertions do not validate JSON. Review error handling, retries, cancellation, and behavior after authentication expiry. Match field naming, nullability, enum values, timestamps, pagination, and error envelopes to the Java API. Check large integer identifiers and decimal values for JavaScript precision loss.

## React correctness and usability

- Reproduce stale closures, missing effect dependencies, update races, and missing cleanup when they cause observable failure. Prefer an event handler over an effect when the operation is event-driven.
- Check list identity when items reorder, form state across navigation, duplicate submission, loading states, and stale network results overwriting newer state.
- Inspect state ownership and derived state for contradictions. Propose architectural refactors only when supported by actual complexity or a defect.
- Review accessible names, labels, keyboard operation, focus management, semantic elements, and announced errors for affected interactions.
- Assess expensive rendering, large lists, and bundle loading using measurement or a clear execution path. Inline callbacks, lack of memoization, file length, and prop depth alone are not defects.
- For SSR/hydration, check browser-only APIs, differing initial output, and cross-request data isolation where applicable.

## TypeScript and Node

Inspect unsafe casts, unchecked indexing, discriminated-union handling, swallowed errors, floating promises, and misuse of non-null assertions. Respect configured strictness; propose changes only where a meaningful failure can be demonstrated.

For actual Node services or scripts, check shell/process arguments, path containment, unsafe parsing, HTTP request limits, resource cleanup, async failure propagation, and blocking work on the event loop. Match Express or other framework behavior to its version. Do not demand Express middleware in a React-only build project. Check ESM/CommonJS assumptions and runtime API support against Node 22 or the detected supported version.

## npm and supply chain

Inspect dependency/lockfile consistency, workspace overrides, lifecycle scripts, registry configuration, and CI install behavior. Distinguish runtime dependencies from build/test packages while considering that build tooling can also be attacked. Do not run `npm audit fix --force` or delete/regenerate a lockfile as a generic remediation. Select a compatible patched version, preserve intended constraints, and retest consumers.

Use component tests for visible behavior and asynchronous state transitions, contract tests for API assumptions, and end-to-end tests for critical user flows. Avoid snapshots as the sole evidence for security or behavioral correctness.
