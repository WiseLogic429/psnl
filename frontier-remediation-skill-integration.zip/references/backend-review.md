# Backend review

Apply checks to reachable behavior and the detected framework version. Establish the Java compiler release/toolchain and runtime from Maven/Gradle, CI, and container configuration. For Spring Boot 3 versus 4, consult version-matched APIs; do not mix Spring Security generations or migrate Jackson/test frameworks as incidental cleanup.

## Security boundary review

Start from affected HTTP routes, messages, scheduled work, and outbound integrations. Identify the caller, trusted identity source, protected resource, and enforcement location. Check authorization for reads and writes, batch actions, exports, alternate routes, and administrative functions. Test valid access as well as denial. Do not infer protection merely from a role annotation or an opaque identifier.

Verify that method authorization is enabled and exercised through Spring-managed objects. Inspect filter-chain selection and fallback routes. Evaluate cookies, sessions, bearer tokens, and browser credential behavior together before changing CSRF/CORS. Inspect the actual JWT decoder/provider configuration, token expiry and intended recipient checks, and refresh/logout behavior. Avoid replacing working authentication machinery with handcrafted parsing.

Follow externally supplied values into SQL/JPQL, dynamic ordering, expression engines, process execution, redirects, filesystem access, and outbound requests. Parameterization does not protect concatenated identifiers. Assess outbound destination validation across redirects and resolution. Evaluate upload storage, extraction paths, content handling, and resource limits. Inspect exposed management/configuration surfaces and error responses in deployed configuration, including gateway controls when present.

Inspect writable DTOs and mapping logic for client-controlled privileges or ownership. Check secret exposure in configuration, responses, logs, tracing, and exception details without reproducing secret values in reports. Evaluate password handling and cryptographic APIs against current official guidance when relevant.

## Correctness and data integrity

- Validate nullability, empty inputs, nested validation, pagination bounds, and serialization contracts at real request boundaries.
- Check transaction behavior under proxy calls, exceptions, retries, async work, and external side effects. Identify partial commits and duplicated operations.
- Review concurrent updates, optimistic locking, idempotency keys, and uniqueness constraints where the domain requires them.
- Inspect query count, fetch behavior, pagination, and connection usage with evidence; do not label every lazy relationship an N+1 defect.
- Check money precision/rounding, time zones, date boundaries, and overflow where they affect domain behavior.
- Verify error-to-status mapping and consistent client-visible contracts; avoid leaking implementation details.
- Examine timeout, cancellation, retry/backoff, and resource ownership for outbound calls and background jobs.

## Java 21 and later

Check executor lifecycle, thread safety, interrupt handling, resource closure, and propagation of security/logging context. Virtual threads do not increase database connection limits or make shared mutable objects safe. Evaluate blocking and pinning behavior against the actual JDK version; do not generalize behavior across releases. Preserve non-preview compilation unless the project explicitly enables preview features. Avoid imposing records, sealed types, or virtual threads without a demonstrated benefit.

## Test selection

Use focused unit tests for pure logic, HTTP/security tests for request behavior, and database integration tests for query/transaction guarantees. A mocked repository cannot establish SQL isolation or constraints. A manually constructed service cannot establish Spring proxy behavior. Choose fixtures for the reported defect, including legitimate success cases, and keep synthetic data isolated.
