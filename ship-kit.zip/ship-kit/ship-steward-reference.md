# Claude Ship: consolidated reference for `/ship` and `/steward`

Written in my own words from Anthropic's Claude Code docs as read on 2026-11-25. Treat the docs as the source of truth, because this feature is new and changing. Pages used:

- https://code.claude.com/docs/en/ship-command.md
- https://code.claude.com/docs/en/ship-command-troubleshooting.md
- https://code.claude.com/docs/en/pr-steward.md
- https://code.claude.com/docs/en/pr-steward-setup.md
- https://code.claude.com/docs/en/pr-steward-pull-requests.md
- https://code.claude.com/docs/en/pr-steward-security.md
- https://code.claude.com/docs/en/pr-steward-troubleshooting.md
- https://code.claude.com/docs/en/claude-ship.md

---

## 1. The big picture

**Claude Ship** is a set of agents for GitHub pull requests, announced November 23, 2026:

| Agent | Job | Status | Runs where |
|---|---|---|---|
| Code Review | Finds problems and posts findings | Generally available | Cloud (org-billed) or locally via `/code-review` |
| PR Steward | Fixes failing checks, merge conflicts, review feedback | Public beta | Anthropic cloud, as the Claude GitHub App |
| Claude Approvals | Applies an approval policy (`.claude/approvals.yml`) | Public beta | Anthropic cloud |

Org-level agents need a Claude Team or Enterprise plan and an Owner to enable them. Not available with Zero Data Retention, the HIPAA configuration, or customer-managed encryption keys.

`/ship` and `/steward` are the **local** versions. They are Claude Code commands, run in your own terminal session, act as you, and count against your own usage. They do not need org setup.

## 2. Requirements for the local commands

- Claude Code v2.1.330 or later (v2.1.331+ fixes several behaviors; use the latest).
- GitHub CLI (`gh`) 2.63 or later, signed in (`gh auth login`). Older `gh` means no watch starts.
- git 2.38 or later (needed to merge new commits into your branch).
- A local clone of a GitHub repo. Cloud sessions don't have these commands.
- Permission mode: auto mode if you want unattended work. In manual or `acceptEdits` mode Claude waits at each prompt. `bypassPermissions` mode: no watch starts. Plan mode: `/ship` won't start.
- Not supported for watches: native Windows, background sessions.

## 3. `/ship` flow (finished change, no PR yet or PR open)

1. **Pull request:** commit your work, push the branch, open a PR as you.
2. **Review:** run `/code-review` on the change (effort `low|medium|high|xhigh|max`, default `high`).
3. **Watch:** keep checking the PR from the session; fix failing checks, merge conflicts, reviewer comments, and review findings; push fixes.
4. **Merge:** you merge it yourself.

### What `/ship` commits and pushes

- Runs with no confirmation prompt. A line ending "Esc to cancel" appears before the commit and again before the push, then it continues after a few seconds.
- If you're on the default branch, it commits on a **new branch** and switches your checkout to it. If commits are already on another branch, it pushes that branch and opens the PR.
- It never pushes the default branch. It sets no upstream.
- The commit message is written from the session's conversation. If it can't, it falls back to a line like "Update foo.py and 1 more".
- It only works on github.com repos that aren't forks. For drafts, other base branches, PR templates, GitHub Enterprise, or forks: open the PR yourself, then run `/ship`.

### Cases where `/ship` does something else (first match wins)

| Case | Behavior |
|---|---|
| Someone else's PR is open for the branch | Doesn't commit or push; no watch |
| An uncommitted file's name suggests a secret (`.env`, `password.txt`) in a non-public repo | Commits and pushes nothing |
| Your own PR already open | Can commit uncommitted changes, push them plus unpushed commits. In some cases (public repo, auto-merge on, merge/cherry-pick in progress) it won't commit your uncommitted changes |
| Repo is public | Doesn't commit uncommitted changes; may push existing commits and open the PR without them |
| Commits on the default branch, nothing uncommitted | Makes a new branch for them, pushes, opens a PR |
| Changed files that configure git, CI, or agents (`.gitignore`, `CLAUDE.md`, `.github/**`) | Leaves the commit to you |
| Detached HEAD or mid-rebase | Does nothing; fix first |
| Empty sandbox mask files (`.bashrc`, `.gitconfig`) that you didn't create | Leaves them alone |

It looks for secrets **by file name only**. You should check file contents yourself. A `Read(...)` deny rule does not keep a file out of a commit.

## 4. `/steward` (PR already open, no review first)

Skips steps 1 and 2 and starts the watch. Use on your own open PR, or to restart a watch that ended. It requires the PR's branch to be checked out locally. Where the org PR Steward is already working on the PR, no local watch starts.

## 5. The watch: what Claude does (auto mode, GitHub PR)

Without asking, it:

- Works on the review findings it judges to be real problems
- May post one comment summarizing its review
- Pushes commits to your branch
- Merges the base branch into yours (conflicts, or to catch up)
- Works on failing checks and re-runs failed ones
- Answers review comments, resolves threads, re-requests reviews

It reads comments from you and people with write access, plus Claude's bot on github.com. To read another bot: `/steward +botname`. Unread comments are reported as "N comment(s) not read".

When checks pass and comments are answered, it says so and **you merge**.

Other hosts (GitLab, Bitbucket, Azure DevOps): can watch a branch up to seven days using git only. No commit/push/PR opened at start. Can merge the base in and push, but cannot reply to comments, re-run checks, or read CI logs.

### While a watch runs

- Keep the session open, the computer awake, and the PR branch checked out. Claude edits the same checkout you use.
- Work on the next change in a second clone with a second session.
- Push your own commits with `git push origin <branch>` (no `-u`; changing upstream ends the watch).
- Unpushed commits can go up with Claude's next push.
- When Claude acts without a message from you, git stash/reset/checkout, `add -A`, and `commit -a` are refused.

### What ends a watch

PR merged or closed; seven days; Esc or Ctrl+C; you check out another branch or change git config; session ends, `/clear`, `/resume`, `/branch`; you start a `/loop` or run `/ship`//`steward` again; plan mode; an error, declined prompt, or usage limit; a file the watch relies on changes (git config, `.claude/settings.local.json`); the org PR Steward labels the PR.

## 6. Arguments

| You type | Effect |
|---|---|
| `low|medium|high|xhigh|max` | Review effort for `/ship` (default `high`); put first |
| `41` or a PR URL | Work on that PR (watch needs your own PR checked out) |
| `+botname` | Also read that bot's comments |
| `origin/main` | Base branch on non-GitHub hosts |
| `stop` | End the watch |
| `terms` | Show what Claude may do and what limits it |

Check a running watch with `/tasks` (shows as a scheduled `/steward --tend` task while Claude is idle).

## 7. Guardrails

- During unattended turns, Claude Code blocks `gh`/`git` commands that merge, approve, enable auto-merge, or force-push, and limits `gh`/`git` to a short list; connectors, `WebFetch` and `WebSearch` are refused.
- These limits are **not complete**: the watch uses your `gh` and `git` credentials. Auto-merge on the PR, or a message you type while Claude is idle, can lead to a merge. Rules match command text, so another spelling of a command can slip past.
- Code that can run on your machine during a watch with your credentials: the base branch's scripts, other people's pushes, your tests, your hooks, `.claude/skills/steward/SKILL.md`.
- Run a watch only where you trust everyone who can merge to the base branch or push to your branch.
- Org-wide off switch: `CLAUDE_CODE_DISABLE_SHIP=1`, or `skillOverrides` `"ship-local": "off"` and `"steward": "off"`.

## 8. Repo instructions: `.claude/skills/steward/SKILL.md`

Both the local watch and the cloud PR Steward read this file. Example from the docs' pattern:

```markdown
---
name: steward
description: House rules for PR Steward in this repository
user-invocable: false
disable-model-invocation: true
---

- Work on failing checks, merge conflicts, and Important findings from Code Review.
- Leave comments from human reviewers to the author.
- Regenerate `package-lock.json` with `npm install`. Don't edit it directly.
- The `e2e-nightly` check is flaky. Re-run it once before you look for a cause.
```

Do **not** reuse the names `ship`, `ship-local`, or `steward` for a different custom skill. A custom skill with those names stops loading. Leave the repo file `.claude/skills/steward/SKILL.md` as it is; it's read as instructions, not as a command.

## 9. PR Steward (cloud) behavior, for context

Default instructions:

| Work | Default |
|---|---|
| Failing checks | Fix and push when the failure is in code the PR touches |
| Flaky checks | Re-run a failed job once if it failed before any test ran or passed earlier on the same commit |
| Base branch | Merge base in on conflict; may also when behind |
| Lockfiles / generated files | Regenerate |
| Small review requests (rename, add a test) | Push and resolve the thread |
| Large or design-level requests | Reply only, no push, unless the reviewer says which change |
| Code Review optional findings | Reply and resolve; don't push for these alone |
| Choice of approach | Picks one itself |

Visible traces on the PR: labels `claude-pr-steward-watching` and `claude-pr-steward-is-working`; a first comment headed "Claude PR Steward"; progress comments before and after work; commits by `Claude <noreply@anthropic.com>`. **After every push it says what changed and how to undo it** (revert the named commit, or remove the label to stop).

Control: `@claude steward` (start), `@claude stop` (stop), `@claude <instructions>` (steer), remove the label to stop, `<!-- claude-pr-steward-disable -->` in the PR description to keep it off. It skips drafts, forks, bot-opened PRs, authors without write access.

Cloud limits (Anthropic's service refuses): approving a PR, changing branch protection/rulesets/statuses, writing check runs, deleting branches, pushing tags. Merge, auto-merge and force-push are left to GitHub branch rules, so require approvals and keep the Claude GitHub App off the bypass list.

## 10. Troubleshooting cheat sheet

| Symptom | Likely cause / fix |
|---|---|
| `/ship` missing | `claude update`, restart twice; check `disableBundledSkills`, `skillOverrides`, `CLAUDE_CODE_DISABLE_SHIP`; on third-party providers needs v2.1.331+; disable of telemetry can skip feature-flag fetch |
| "Nothing started... line that you type" | Type it yourself; not from `claude -p`, not a prompt suggestion |
| `gh` not installed / signed in | Install, `gh auth login` (`--hostname` for GHE) |
| "this gh is too old for a watch" | Update `gh` to 2.63+ |
| Nothing committed/pushed | Public repo, secret-looking file name, config-file changes, default branch, detached HEAD, or a deny rule on commit/push |
| No watch started | Not your PR, branch not checked out, bypass/plan mode, background session, Remote Control on, deny rule or hook blocking `gh`/`git commit`/`git push`, native Windows |
| Watch stopped | Read the "Stopped watching ... because" line; reasons listed in section 5 |

## 11. What cannot be replicated locally

- The cloud agent (runs with nobody's laptop open, acts as the GitHub App, bills the org).
- Anthropic-side refusal of approvals, branch-protection changes and similar.
- Claude Approvals policy engine.
- Enforcement beyond what permission rules and branch protection give you. Use both.

## 12. Settings to enforce the guardrails (user or project `.claude/settings.json`)

```json
{
  "permissions": {
    "deny": [
      "Bash(gh pr merge *)",
      "Bash(gh pr review * --approve*)",
      "Bash(gh pr review --approve*)",
      "Bash(git push --force*)",
      "Bash(git push -f*)",
      "Bash(git push * --force*)",
      "Bash(git push * -f *)",
      "Bash(git push origin main*)",
      "Bash(git push origin master*)"
    ]
  }
}
```

These match command text, so treat them as a seatbelt, not a lock. The real control is GitHub branch protection: require at least one approval, dismiss stale approvals on new pushes, and block force pushes.
